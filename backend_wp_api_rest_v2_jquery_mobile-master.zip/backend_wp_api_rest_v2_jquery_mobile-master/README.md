# backend_wp_api_rest_v2_jquery_mobile
Integración muy sencilla del API REST de Wordpress con jquery mobile

Modified by Daniel Julià from
previous version in 
https://github.com/scottopolis/wp-rest-api-demo
by scottopolis https://github.com/scottopolis/
